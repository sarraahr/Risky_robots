from pygame_functions import *
import random
from pygame.locals import *
import sys

class Start:
    def __init__(self, screenSize, overall_score):
        self.screenSize = screenSize
        self.overall_score = overall_score
        self.username = None

    def add_name(self):
        screenSize(self.screenSize[0], self.screenSize[1])
        setBackgroundColour("white")

        instruction = makeLabel("Please enter your name: ", 30, 240, 30, "black", "Arial", "white")
        showLabel(instruction)

        wordBox = makeTextBox(240, 110, 300, 0, "Enter Text here", 0, 24)
        showTextBox(wordBox)
        self.username = textBoxInput(wordBox)

        return self.username

    def show_scores(self, overall_score):
        pygame.init()
        self.screen = pygame.display.set_mode(self.screenSize)
        image = pygame.image.load(r"images/trophy.png")

        font = pygame.font.SysFont('arial', 40)

        # später overall_score - 10 oder so
        user_list = [str(self.username)]
        for i in range(0,4):
            newuser = self.randScores()
            user_list.append(newuser)

        place1 = user_list[0] + " :    " + str(overall_score)
        place2 = user_list[1] + " :    " + str(overall_score - 10)
        place3 = user_list[2] + " :    " + str(overall_score - 30)
        place4 = user_list[3] + " :    " + str(overall_score - 40)
        place5 = user_list[4] + " :    " + str(overall_score - 50)
        font2 = pygame.font.SysFont('arial', 60)
        scoretext = font2.render("High Scores", 1, (0, 0, 0))
        text = font.render(place1, 1, (214, 77, 84))
        text2 = font.render(place2, 1, (0, 0, 0))
        text3 = font.render(place3, 1, (0, 0, 0))
        text4 = font.render(place4, 1, (0, 0, 0))
        text5 = font.render(place5, 1, (0, 0, 0))

        while True:
            self.screen.fill((255, 255, 255))
            self.screen.blit(scoretext, (220, 20))
            self.screen.blit(text, (240, 150))
            self.screen.blit(text2, (240, 210))
            self.screen.blit(text3, (240, 270))
            self.screen.blit(text4, (240, 330))
            self.screen.blit(text5, (240, 390))
            self.screen.blit(image, (350, 600))
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
        return


    def randScores(self):
        adjectives = ["happy", "fast", "gold", "amazing", "fun", "sss", "", "", ""]
        nouns = ["Jon", "Digger", "Lea", "Elf", "spider", "Hannah", "Tim", "Cat", "Honey", "Pat", "Gamer", "Tom", "lisa"]
        numbers = ["97", "1", "224", "_1", "_2", "10", "33", ""]

        rand_user = random.choice(adjectives) + random.choice(nouns) + random.choice(numbers)
        return rand_user


