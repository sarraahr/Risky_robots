class Piece:
    def __init__(self, hasCoin):
        self.hasCoin = hasCoin
        self.clicked = False
        self.flagged = False

    def getHasCoin(self):
        return self.hasCoin

    def getClicked(self):
        return self.clicked

    def getFlagged(self):
        return self.flagged


    def toggleFlag(self):
        self.flagged = not self.flagged


    def click(self):
        self.clicked = True


