from piece import Piece
import random
import numpy as np
from menu import Menu


class Board:
    def __init__(self, size, no_coins, no_bombs, payoff_coins, payoff_bombs):
        self.size = size
        self.no_coins = no_coins
        self.no_bombs = no_bombs
        #self.lost = False
        self.won = False
        self.numCoins = 0
        self.setBoard()
        self.payoff_coins = payoff_coins
        self.payoff_bombs = payoff_bombs
        self.score = 0
        self.numClicks = 0
        self.no_coins_now = no_coins
        self.no_bombs_now = no_bombs

    def setBoard(self):
        self.board = []
        no_empty = self.size[0] * self.size[1] - (self.no_coins + self.no_bombs)
        list_of_items = random.sample(list(np.array([1]*self.no_coins + [2]*self.no_bombs + [0]*no_empty)),self.size[0] * self.size[1])
        for row in range(self.size[0]):
            row = []
            for col in range(self.size[1]):
                hasCoin = list_of_items.pop(0)
                piece = Piece(hasCoin)
                row.append(piece)
            self.board.append(row)

    def getSize(self):
        return self.size

    def getPiece(self, index):
        return self.board[index[0]][index[1]]

    def handleClick(self, piece, flag):
        if piece.getClicked() or (not flag and piece.getFlagged()):
            return
        if flag:
            piece.toggleFlag()
            return
        piece.click()
        self.numClicks += 1
        if piece.getHasCoin() == 1:
            self.numCoins += 1
            self.score += self.payoff_coins
            self.no_coins_now = self.no_coins_now - 1
            return self.no_coins_now
        elif piece.getHasCoin() == 2:
            self.score += self.payoff_bombs
            self.no_bombs_now = self.no_bombs_now - 1
            #self.lost = True
            return self.no_bombs_now
        return self.numClicks

    #def getLost(self):
    #    return self.lost

    def getWon(self):
        return self.numCoins == self.no_coins


