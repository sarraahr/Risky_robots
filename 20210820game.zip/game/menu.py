import pygame
from pygame.locals import *
import sys
from start import Start


mainClock = pygame.time.Clock()


class Menu():
    def __init__(self, screenSize, trial):
        self.screenSize = screenSize
        self.screen = pygame.display.set_mode(self.screenSize)
        self.click = False
        pygame.font.init()
        self.font = pygame.font.SysFont('arial', 20)
        lowrisk = trial[0]
        highrisk = trial[1]
        self.text1 = str(lowrisk[0]) + " Coins and " + str(lowrisk[1]) + " Bomb(s)."
        self.text2 = str(highrisk[0]) + " Coins and " + str(highrisk[1]) + " Bomb(s)."

    def draw_text(self, text, font, color, surface, x, y):
        textobj = font.render(text, 1, color)
        textrect = textobj.get_rect()
        textrect.topleft = (x,y)
        surface.blit(textobj, textrect)


    def run(self):
        pygame.init()
        pygame.font.init()
        while True:

            self.screen.fill((255, 255, 255))
            self.draw_text('Which game set up would you like to choose?', self.font, (0,0,0), self.screen, 200, 200)

            mx, my = pygame.mouse.get_pos()

            #pygame.display.set_caption('Window caption') # if I want to add a window caption

            button_1 = pygame.Rect(50, 300, 300, 100)
            button_2 = pygame.Rect(450, 300, 300, 100)
            if button_1.collidepoint((mx, my)):
                if self.click:
                    return "A"
                pass
            if button_2.collidepoint((mx, my)):
                if self.click:
                    return "B"
                pass
            pygame.draw.rect(self.screen, (255, 255, 255), button_1)
            pygame.draw.line(self.screen, (0, 0, 0), (50, 300), (350, 300), 3)
            pygame.draw.line(self.screen, (0, 0, 0), (50, 400), (350, 400), 3)
            pygame.draw.line(self.screen, (0, 0, 0), (50, 300), (50, 400), 3)
            pygame.draw.line(self.screen, (0, 0, 0), (350, 300), (350, 400), 3)
            self.screen.blit(self.font.render('Option A', True, (0, 0, 0)), (60, 305))
            self.screen.blit(self.font.render(self.text1, True, (0, 0, 0)), (60, 350))

            pygame.draw.rect(self.screen, (255, 255, 255), button_2)
            pygame.draw.line(self.screen, (0, 0, 0), (450, 300), (750, 300), 3)
            pygame.draw.line(self.screen, (0, 0, 0), (450, 400), (750, 400), 3)
            pygame.draw.line(self.screen, (0, 0, 0), (450, 300), (450, 400), 3)
            pygame.draw.line(self.screen, (0, 0, 0), (750, 300), (750, 400), 3)

            self.screen.blit(self.font.render('Option B', True, (0, 0, 0)), (460, 305))
            self.screen.blit(self.font.render(self.text2, True, (0, 0, 0)), (460, 350))

            self.click = False
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN:
                    if event.kex == K_ESCAPE:
                        pygame.quit()
                        sys.exit
                if event.type == MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.click = True

            pygame.display.update()
            mainClock.tick(60)








