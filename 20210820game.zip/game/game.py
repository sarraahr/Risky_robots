import pygame
import os
from time import sleep



class Game:

    def __init__(self, board, screenSize, finalscore, username):
        self.board = board
        self.screenSize = screenSize
        self.pieceSize = self.screenSize[0] // self.board.getSize()[1], self.screenSize[1] // self.board.getSize()[0]
        self.loadImages()
        self.exit_button = pygame.Rect(0, 0, 70, 40)
        self.click = False
        self.finalscore = finalscore
        self.username = username
        self.expected_value = None
        self.evalue_clicks = []

    def run(self):
        pygame.init()
        self.screen = pygame.display.set_mode(self.screenSize)
        running = True

        while running:
            self.calc_exp()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.evalue_clicks.append(self.expected_value)
                    position = pygame.mouse.get_pos()
                    rightClick = pygame.mouse.get_pressed()[2]
                    self.handleClick(position, rightClick)
            self.draw()
            self.display_score()
            self.exit_func()
            self.exit()

            pygame.display.flip()
            if self.board.getWon():
                sleep(1)
                running = False
                return self.board.numCoins
            if self.exit():
                running = False
                return self.board.numCoins
        pygame.quit()

    def draw(self):
        topLeft = (0, 0)
        for row in range(self.board.getSize()[0]):
            for col in range(self.board.getSize()[1]):
                piece = self.board.getPiece((row, col))
                image = self.getImage(piece)
                self.screen.blit(image, topLeft)
                topLeft = topLeft[0] + self.pieceSize[0], topLeft[1]
            topLeft = 0, topLeft[1] + self.pieceSize[1]

    def loadImages(self):
        self.images = {}
        for fileName in os.listdir("images"):
            if (not fileName.endswith(".png")):
                continue
            image = pygame.image.load(r"images/" + fileName)
            image = pygame.transform.scale(image, self.pieceSize)
            self.images[fileName.split(".")[0]] = image

    def getImage(self, piece):
        if (piece.getClicked()):
            if piece.getHasCoin() == 1:
                string = "coin"
            elif piece.getHasCoin() == 2:
                string = "bomb"
            else:
                string = "empty"
        else:
            string = "flag" if piece.getFlagged() else "soil"

        return self.images[string]

    def handleClick(self, position, rightClick):
        # if self.board.getLost():
        #    return
        index = position[1] // self.pieceSize[1], position[0] // self.pieceSize[0]
        piece = self.board.getPiece(index)
        self.board.handleClick(piece, rightClick)

    def display_score(self):
        font = pygame.font.SysFont('arial', 20)
        scoretext = "Score: " + str(self.board.score) + "   Overall: " + str(
            self.finalscore + self.board.score) + "   " + str(self.username)
        text = font.render(scoretext, 1, (250, 250, 250))  # + str(self.score)
        self.screen.blit(text, (250, 10))
        return

    def exit_func(self):
        font = pygame.font.SysFont('arial', 20)
        pygame.draw.rect(self.screen, (255, 255, 255), self.exit_button)
        self.screen.blit(font.render('Exit', True, (0, 0, 0)), (10, 5))
        return

    def exit(self):
        exit_clicked = False
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if self.exit_button.collidepoint((mouse[0], mouse[1])):
            if click[0] == 1:
                exit_clicked = True
        else:
            exit_clicked = False

        return exit_clicked

    def calc_exp(self):
        try:
            self.expected_value = (self.board.no_coins_now / (
                    self.board.size[0] * self.board.size[1] - self.board.numClicks)) * self.board.payoff_coins + (self.board.no_bombs_now / (self.board.size[0] * self.board.size[1] - self.board.numClicks)) * self.board.payoff_bombs
        except:
            self.expected_value = 0
        return self.expected_value


