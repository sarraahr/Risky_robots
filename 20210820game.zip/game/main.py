from game import Game
from board import Board
import random
import pandas as pd
from menu import Menu
import pygame
from start import Start
import os

pygame.init()
pygame.font.init()

# adjustable parameters of the board
screenSize = (800, 800)  # if changed, positions of fonts, images, etc. have to be adjusted
size = (6, 6)  # can be changed to any n x m grid
payoff_coins = 10
payoff_bombs = -30

csv_path = os.path.dirname(os.path.abspath(__file__))  # to ensure a relative path to the working directory
overall_score = 0

# logging information
trial_list = []
round_list = []
score_list = []
clicks_list = []
evalue_list = []
choice_list = []
options_list = []
exp_dic = {}

# start the game and get username
start = Start(screenSize, overall_score)
username = start.add_name()

# main game loops (currently set to 3 rounds with 10 trials each)
for round in range(1, 4):  # change range for number of rounds
    # list of coins and bombs as tuples (coin, bomb), low-risk left and high-risk right
    list_coins_bombs = [((4, 1), (10, 4)), ((5, 1), (11, 4)), ((6, 1), (13, 5)), ((7, 2), (14, 5)), ((8, 2), (15, 6)),
                        ((9, 2), (16, 6)), ((6, 2), (11, 4)), ((7, 2), (16, 6)), ((5, 1), (13, 5)), ((6, 1), (15, 6))]
    random.shuffle(list_coins_bombs)

    for trial in range(0, 10):  # change for number of trials per round
        choices = list_coins_bombs.pop(0)

        menu = Menu(screenSize, choices)
        choice = menu.run()
        if choice == "A":
            option_picked = choices[0]
        elif choice == "B":
            option_picked = choices[1]

        no_coins = option_picked[0]
        no_bombs = option_picked[1]

        no_clicks = None
        board = Board(size, no_coins, no_bombs, payoff_coins, payoff_bombs)
        game = Game(board, screenSize, overall_score, username)
        coins = game.run()
        overall_score += board.score

        # logging information
        round_list.append(round)
        trial_list.append(trial)
        options_list.append(choices)
        choice_list.append(choice)
        score_list.append(board.score)
        clicks_list.append(board.numClicks)
        evalue_list.append(game.expected_value)
        key = str(round) + "." + str(trial)
        exp_dic[key] = game.evalue_clicks

d = {'Round': round_list, 'Trial': trial_list, 'Options': options_list, 'Choice': choice_list, 'Score': score_list,
     'NoClicks': clicks_list, 'Expected Value': evalue_list}
df = pd.DataFrame(d)
path = csv_path + "/data/" + str(username) + ".csv"
df.to_csv(path, index=False)

df2 = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in exp_dic.items()]))
path2 = csv_path + "/data/" + "ExpectedValues.csv"
df2.to_csv(path2, index=False)
start.show_scores(overall_score)
